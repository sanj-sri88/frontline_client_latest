import Main from './pages/Main';
import "./styles/main.less";

console.log('Running APP', process.env.NODE_ENV);

export default Main;
