import React from "react";

const NGO = () => {
  return (
    <div style={{ textAlign: "left" }}>
      <h2>NGO Demo Page</h2>
      <div style={{ marginTop: 30 }}>placeholder</div>
    </div>
  );
};

export default NGO;
