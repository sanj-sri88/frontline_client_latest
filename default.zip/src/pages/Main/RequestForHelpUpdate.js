import React, { useEffect } from "react";
import RequestForHelpUpdateForm from "@components/VolunteerForm/RequestForHelpUpdateForm";
import options from "@utils/Options";
import formatter from "@utils/Formatter";
import { connecter } from "@store/RequestForHelpUpdate";

function RequestForHelpUpdate({
  save,
  reset,
  getRequestForHelpDetail,
  record,
  getMLSuggestedFields,
}) {
  // default to Karnataka, Bangalore
  const initialValues = {
    region: [],
    meta: {},
  };
  const region = ["KA"];

  useEffect(() => {

    getRequestForHelpDetail(location.hash.split("?")[1]);

    let descdata = {

      "query": "toothbrush, soap, rice, wheat, daal", //get Data from API Relief Type
      "multi-label": true

    }
    getMLSuggestedFields(descdata);
  }, []);

  function handleSubmit(formData) {
    if (formData) {
      formData.id = location.hash.split("?")[1];
      formData.act = "subrequest";
      region.push(formData.region);
      formData["region"] = region;
      formatter(formData);
      save(formData);
    }
  }
  console.log(" Record : ", record);
  /*let descdata = {

    "query": record.desc,
    "multi-label": true

  }*/




  return (
    <div style={{ textAlign: "left" }}>
      <h2>Request for Help Update</h2>
      <div style={{ marginTop: 30 }}>
        <RequestForHelpUpdateForm
          {...options}
          onSubmit={handleSubmit}
          initialValues={initialValues}
          reset={reset}
          record={record}
        />
      </div>
    </div>
  );
}

export default connecter(RequestForHelpUpdate);
