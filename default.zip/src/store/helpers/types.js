const reportTypes = [
  "SET_RESULT",
  "SEARCH",
  "SET_MODE",
  "SET_REGION",
  "SET_SERVICE",
  "SET_PAGINATION",
  "SET_DATE_RANGE",
  "EXPORT_CSV",
  "SET_STATUS",
  "UPDATE_STATUS",
  "UPDATE_RESULT",
];

export { reportTypes };
