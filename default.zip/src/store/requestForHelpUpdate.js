import update from "immutability-helper";
import { connect } from "react-redux";
import { applyScope } from "./utils";
import { pageSelector } from "./selectors";

import { createSelector } from "reselect";

const scope = "requestForHelpUpdate";

const initialState = {
  reset: 1,
  record: {},
  reliefields: {} //Relief Type
};

export const types = applyScope(scope, [
  "SET_RESET",
  "SAVE",
  "FETCH_REQUEST_FOR_HELP_DETAIL",
  "SET_DATA",
  "NAVIGATE_TO_REPORT",
  "GET_MLSuggestedReliefTypes", //Relief Type
  "FETCH_ML_SUGGESTED_FIELD" //Relief Type

]);

const requestForHelpUpdateReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.SET_RESET:
      return update(state, {
        reset: { $set: state.reset + 1 },
      });
    case types.SET_DATA:
      return update(state, {
        record: { $set: action.record },
      });
    case types.NAVIGATE_TO_REPORT:
      return update(state, {
        naviagteToReport: { $set: action.naviagteToReport },
      });
    case types.GET_MLSuggestedReliefTypes: //Relief Type
      return update(state, {
        reliefields: { $set: action.reliefields }
      })



  }
  return state;
};

// dispatch actions
const mapDispatchToProps = (dispatch) => ({
  setReset: () =>
    dispatch({
      type: types.SET_RESET,
    }),
  save: (formData) =>
    dispatch({
      type: types.SAVE,
      formData,
    }),
  getRequestForHelpDetail: (requestID) =>
    dispatch({
      type: types.FETCH_REQUEST_FOR_HELP_DETAIL,
      requestID,
    }),
  //Get ML Relief Type
  getMLSuggestedFields: (data) =>
    dispatch({
      type: types.FETCH_ML_SUGGESTED_FIELD,
      data,
    }),
  setReliefTypeField: (reliefields) =>
    dispatch({
      type: types.GET_MLSuggestedReliefTypes,
      reliefields
    }),


  setData: (record) =>
    dispatch({
      type: types.SET_DATA,
      record,
    }),
});

const getResult = (state) => state[scope].record;
export const parsedResultSelector = createSelector([getResult], (record) => {
  const parsedResult = record && record.data ? record.data : {};
  return parsedResult;
});

// state from root state
//const mapStateToProps = pageSelector(scope);
const mapStateToProps = pageSelector(scope, { record: parsedResultSelector });

// connect
export const connecter = (vs) =>
  connect(mapStateToProps, mapDispatchToProps)(vs);

export default requestForHelpUpdateReducer;
