import IndividualForm from "./IndividualForm";
import OrganizationForm from "./OrganizationForm";
import IndividualKindForm from "./IndividualKindForm";
import OrganizationKindForm from "./OrganizationKindForm";
import NgoForm from "./NgoForm";

export {
  IndividualForm,
  OrganizationForm,
  NgoForm,
  IndividualKindForm,
  OrganizationKindForm,
};
