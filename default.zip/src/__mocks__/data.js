const noop = () => undefined;

export default {
  noop
};
